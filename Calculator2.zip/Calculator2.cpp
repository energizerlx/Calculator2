#include "Calculator2.h"

Calculator2::Calculator2(){

}

int Calculator2::Plus(int x , int y) {
  _x=x;
  _y=y;
  _sum=sum;
  _sum = _x + _y;
  return _sum;
}
int Calculator2::Minus(int x , int y) {
  _x=x;
  _y=y;
  _sum=sum;
  _sum = _x - _y;
  return _sum;
}
int Calculator2::Multiplied(int x , int y) {
  _x=x;
  _y=y;
  _sum=sum;
  _sum = _x * _y;
  return _sum;
}
int Calculator2::Divide(int x , int y) {
  _x=x;
  _y=y;
  _sum=sum;
  _sum = _x / _y;
  return _sum;
}
