#include "Calculator2.h"

Calculator2::Calculator2(){

}

int _x=x;
int _y=y;

Calculator2::Plus(int x , int y) {
  sum = _x + _y;
  return sum;
}
Calculator2::Minus(int x , int y) {
  sum = _x - _y;
  return sum;
}
Calculator2::Multiplied(int x , int y) {
  sum = _x * _y;
  return sum;
}
Calculator2::Divide(int x , int y) {
  sum = _x / _y;
  return sum;
}
