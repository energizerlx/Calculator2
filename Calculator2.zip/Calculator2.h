#ifndef Calculator2_h   //#ifndef ตามด้วยชื่อไลบรารีที่ต้องการ _h
#define Calculator2_h  //#define ตามด้วยชื่อไลบรารีที่ต้องการ _h
#include "Arduino.h"

class Calculator2{
public:
  int sum = 0;
  Calculator2();
  void Plus(int x , int y);
  void Minus(int x , int y) ;
  void Multiplied(int x , int y);
  void Divide(int x , int y) ;

private:
  int _x;
  int _y;
};
#endif
